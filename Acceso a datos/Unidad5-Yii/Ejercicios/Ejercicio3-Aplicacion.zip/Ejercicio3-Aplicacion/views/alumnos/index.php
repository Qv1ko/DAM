<?php

use app\models\alumnos;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;

/** @var yii\web\View $this */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->title = 'Alumnos';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="alumnos-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Alumnos', ['create'], ['class' => 'btn btn-success']) ?>
    </p>


    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id_alumno',
            'dni',
            'nombre',
            'apellidos',
            'curso',
            //'aula',
            //'turno',
            //'estado_matricula',
            //'id_portatil',
            //'id_cargador',
            //'id_raton',
            [
                'class' => ActionColumn::className(),
                'urlCreator' => function ($action, alumnos $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id_alumno' => $model->id_alumno]);
                 }
            ],
        ],
    ]); ?>


</div>
