<?php
    use yii\grid\GridView;
?>

<div class="jumbotron text-center">
    <h2><?=$titulo?></h2>
    <p class="lead"><?=$enunciado?></p>
    <div class="well"></div>
</div>

<?=
    GridView::widget([
        'dataProvider' => $resultados,
        'columns' => $campos
    ]);   
?>
